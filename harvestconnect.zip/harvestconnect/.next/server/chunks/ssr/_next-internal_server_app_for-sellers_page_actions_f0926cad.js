module.exports=[5684,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_for-sellers_page_actions_f0926cad.js.map