module.exports=[75764,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_community_farmers_page_actions_4720fb61.js.map