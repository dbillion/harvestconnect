module.exports=[60487,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_new_page_actions_6664d981.js.map