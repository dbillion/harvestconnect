module.exports=[59685,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_auth_callback_github_page_actions_e874ad23.js.map