module.exports=[46323,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_manage_page_actions_51a9ba42.js.map