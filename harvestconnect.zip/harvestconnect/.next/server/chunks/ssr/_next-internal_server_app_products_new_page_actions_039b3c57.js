module.exports=[57894,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_products_new_page_actions_039b3c57.js.map