module.exports=[83814,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_marketplace_%5Bid%5D_page_actions_0b6decc8.js.map