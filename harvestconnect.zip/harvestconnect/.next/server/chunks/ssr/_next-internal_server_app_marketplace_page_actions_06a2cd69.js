module.exports=[15516,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_marketplace_page_actions_06a2cd69.js.map