module.exports=[71478,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_articles_edit_%5Bid%5D_page_actions_d6eb4bf9.js.map