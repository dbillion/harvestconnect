module.exports=[28530,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mission_page_actions_a2b3130f.js.map