module.exports=[10613,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_artists_page_actions_bbb6c7c5.js.map