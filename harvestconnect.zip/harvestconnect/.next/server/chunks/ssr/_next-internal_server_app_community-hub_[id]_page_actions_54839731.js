module.exports=[94081,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_community-hub_%5Bid%5D_page_actions_54839731.js.map