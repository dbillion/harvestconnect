module.exports=[25438,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dev_simulate_page_actions_b8f1aad4.js.map