var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/checkout/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/[root-of-the-server]__80e1f81c._.js")
R.c("server/chunks/_next-internal_server_app_api_checkout_route_actions_414bfd84.js")
R.m(63437)
module.exports=R.m(63437).exports
